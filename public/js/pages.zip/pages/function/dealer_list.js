function filterRecordsByPage(page)
{
	$('#searchfilter').find('#offset').val(page);
	$('#searchfilter').find('#search').val($('#search').val());
	$('#searchfiltersubmit').trigger('click')
	return true;
}
$(function(){
	 $('#start_date,#end_date').bootstrapMaterialDatePicker({
			format: 'YYYY-MM-DD',
			clearButton: true,
			weekStart: 1,
			time: false
	 });
})

 function showConfirmmesage (veh_id) {
	swal({
		title: "Are you sure?",
		text: "You will not be able to recover this history list!",
		type: "warning",
		showCancelButton: true,
		confirmButtonColor: "#DD6B55",
		confirmButtonText: "Yes, delete it!",
		closeOnConfirm: false
	}, function (isConfirm) {
		if(isConfirm)
		{
			$.post(SITEURL+"admin/delete_entry_list",{'veh_id':veh_id},function(data){
				data=JSON.parse(data);
				if(data.error)
				{					
					showWithTitleMessage(data.error,'');
				}	
				if(data.success)
				{
					swal("Deleted!", "Your history has been deleted.", "success");
					window.location.href=window.location.href;
				}
		    });
		    
	    }
	});
}
	

function changeStatus(status)
{

}