<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <style type="text/css">
      </style>
      <style type="text/css">
      </style>
   </head>
   <body>
      <table border="0" cellpadding="1" cellspacing="1" style="padding:15px 0 15px 0;">
         <tbody>
            <tr>
               <td colspan="8" style="height:5px;text-align: center;"><h1>SPEED LIMITING DEVICE</h1></td>
            </tr>   
            <tr>
               <td colspan="8" style="height:5px;text-align: center;"><h3>ONLINE FITMENT CERTIFICATE</h3></td>
            </tr> 
            <tr>
               <td colspan="8" style="height:5px;text-align: center;"><h3>(COMPLIANCE TO AIS 018,AIS 037 STANDARD)</h3></td>
            </tr> 
            <tr>
               <td colspan="8" style="height:5px;text-align: center;"><h5>AIS004 (PART-3)</h5></td>
            </tr>          
         </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" style="padding:15px 0 15px 0;border-bottom: 0px solid white;border-top: 1px solid #000;
         border-left: 1px solid #000;border-right: 1px solid #000;">
         <tbody>
            <tr>
               <td colspan="4" style="height:5px;"></td>
            </tr>
            <tr>
               <td  style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">RTO:</strong>
               </td>
               <td  style="font:15px arial;color:#000;">TN 47 RTO KARUR</td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Dealer ID:</strong>
               </td>
               <td style="font:15px arial;color:#000;">7</td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Vehicle No:</strong>
               </td>
               <td style="font:15px arial;color:#000;">TAN 9954</td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Date:</strong>
               </td>
               <td style="font:15px arial;color:#000;">26-05-2017</td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Chassis No:</strong>
               </td>
               <td style="font:15px arial;color:#000;">ALEF10297</td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Validity:</strong>
               </td>
               <td style="font:15px arial;color:#000;">From 26-05-2017 to 26-05-2017</td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Engine No:</strong>
               </td>
               <td style="font:15px arial;color:#000;">ALEF10297</td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">SLD Make:</strong>
               </td>
               <td style="font:15px arial;color:#000;">HOVEL</td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Vehicle Make:</strong>
               </td>
               <td style="font:15px arial;color:#000;">ASHOK LAYLAND</td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">SLD SERIAL NO:</strong>
               </td>
               <td style="font:15px arial;color:#000;">B444452</td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">RTO :</strong>
               </td>
               <td style="font:15px arial;color:#000;">TN 47 RTO KARUR</td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Dealer ID:</strong>
               </td>
               <td style="font:15px arial;color:#000;">7</td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Vehicle Model:</strong>
               </td>
               <td style="font:15px arial;color:#000;">COMTE</td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Tag NO:</strong>
               </td>
               <td style="font:15px arial;color:#000;">CA00048</td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Owner Name:</strong>
               </td>
               <td style="font:15px arial;color:#000;">Senthil</td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Set Speed:</strong>
               </td>
               <td style="font:15px arial;color:#000;">65</td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Phone:</strong>
               </td>
               <td style="font:15px arial;color:#000;">8489393925</td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">COP Validity:</strong>
               </td>
               <td style="font:15px arial;color:#000;">30-09-2018</td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Invoice No:</strong>
               </td>
               <td style="font:15px arial;color:#000;">321</td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;"></strong>
               </td>
               <td style="font:15px arial;color:#000;"></td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Owner Address:</strong>
               </td>
               <td style="font:15px arial;color:#000;">
                  <address style="border: 1px solid grey;">
                     Test Address, 
                     Test Address,Test Address, 
                     Test Address, Test Address, 
                     Test Address, Test Address, 
                     Test Address,
                  </address>
               </td>
               <td style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Dealer Address:</strong>
               </td>
               <td style="font:15px arial;color:#000;">
                  <address style="border: 1px solid grey;">
                     Test Address, 
                     Test Address,Test Address, 
                     Test Address, Test Address, 
                     Test Address, Test Address, 
                     Test Address,
                  </address>
               </td>
            </tr>
         </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0" style="padding:15px 0 15px 0;border-top: 0px solid white;border-bottom: 1px solid #000;
         border-left: 1px solid #000;border-right: 1px solid #000;">
         <tbody>
            <tr>
               <td colspan="2" style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Certificate QR Code:</strong>
               </td>
               <td  colspan="2"  style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Vehicle Photo:</strong>
               </td>
               <td  colspan="2"  style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">Speed Governor Photo:</strong>
               </td>
            </tr>
            <tr>
               <td  colspan="2" style="font:15px arial;color:#000;">
                  <img src="<?php echo base_url(); ?>public/qrcode/1498889919.png" />
               </td>
               <td  colspan="2" style="font:15px arial;color:#000;">
                  <img src="<?php echo base_url(); ?>public/qrcode/1498889919.png" />
               </td>
               <td  colspan="2" style="font:15px arial;color:#000;">
                  <img src="<?php echo base_url(); ?>public/qrcode/1498889919.png" />
               </td>
            </tr>
            <tr>
               <td colspan="2" style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;"></strong>
               </td>
               <td  colspan="2"  style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;"></strong>
               </td>
               <td  colspan="2"  style="font:15px arial;color:#666;text-align: right;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;text-align: right;">Authorised:</strong>
               </td>
            </tr>
             <tr>
               <td colspan="4" style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">This is to certify that following vehicle has been fitted with approved <b>HOVEL</b> Electronic speed Governor, Which is set to a maximum per set speed 65Kmph(+/- 2%) and shall now exceed this speed in any circumstances.unless the device is tempered or the seal is broken by unauthorised technicians or indiviidual.</strong>
               </td>
                <td  colspan="2">
                  
               </td>
            </tr>
            <tr>
               <td colspan="4" style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">We have sealed this device at critical points and the cerificate is being issued only after testing.</strong>
               </td>
                <td  colspan="2">
                  
               </td>
            </tr>
         </tbody>
      </table>

      <table border="0" cellpadding="5" cellspacing="0" style="padding:15px 10px 15px 0;margin-top:10px;">
         <tbody>
            <tr>
               <td colspan="4" style="font:15px arial;color:#666;">
                  <strong style="padding-top:5px;font:15px arial;color:#666;">For repairs and breakdown please contact the respective Ditrict Dealers. if not attended within 2 working days please inform us in writing E-mail:info@tediiindia.com Toll Free No 1800 121 5800</strong>
               </td>              
            </tr>            
         </tbody>
      </table>
   </body>
</html>