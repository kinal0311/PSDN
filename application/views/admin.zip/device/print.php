 <?php  
 $this->load->view('common/admin_login_header'); ?>
 <?php
 $user_type=$this->session->userdata('user_type');

 ?>
 <!-- Bootstrap Material Datetime Picker Css -->
 <link href="<?php echo base_url() ?>public/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />

 <!-- Wait Me Css -->
 <link href="<?php echo base_url() ?>public/plugins/waitme/waitMe.css" rel="stylesheet" />

 <!-- Bootstrap Select Css -->
 <link href="<?php echo base_url() ?>public/plugins/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />
<style>
.glyphicon { 
  line-height: 2 !important;  
}
.pagination>li>a, .pagination>li>span { border-radius: 50% !important;margin: 0 5px;}
</style>
<body class="<?php echo THEME_BODY_HEADER_COLOR; ?>">
    <?php $this->load->view('common/top_search_bar'); ?>  
   <?php $this->load->view('common/dashboard_top_bar'); ?> 
  <?php $this->load->view('common/left_side_bar'); ?>


    <section class="content">
        <div class="container-fluid">
            <div class="block-header" style="display:none;">
                <h2>
                    Serial Number List
                </h2>
            </div>
            <!-- Basic Validation -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                               Print Stickers
                            </h2>   
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <!-- <ul class="dropdown-menu pull-right">
                                        <li><a href="<?php echo base_url().'admin/create_rto'; ?>">Create</a></li>                                        
                                    </ul> -->
                                </li>
                            </ul>                         
                        </div>
                        <div class="body">
            
            
                             <div class="table-responsive">
          <!--- Search---->
                <form action="<?php echo base_url() ?>device/print" name="searchfilter"  id="searchfilter" method="get" />       
                    <input type="hidden" name="offset"   id="offset" value="<?php echo isset($_GET['offset'])?$_GET['offset']:0; ?>">       
                    <div class="row clearfix">
                      <div class="col-sm-4">
                        <div class="form-group">
                          <div class="form-line">
                            <input type="text" class="form-control" placeholder="Search by IMEI, ICCID, Serial No." id="search" value="<?php echo isset($_GET['search'])?$_GET['search']:""; ?>" name="search">
                          </div>
                        </div>
                      </div>                  
                      
                      <div class="col-sm-4">
                        <div class="form-group">
                          <div class="">
                            <button class="btn btn-primary waves-effect" type="submit" id="searchfiltersubmit" name="searchfiltersubmit">Search</button>
                          </div>
                        </div>
                      </div>
                    
                    <div id="divToPrint" style="display:none;">
                        <div style="width:600px;height:300px;background-color:white;">
                        <!-- <div style="width:200px;height:300px;background-color:teal;"> -->
                            <?php echo $printHtml; ?>      
                        </div>
                    </div>
                    <div>
                        <input type="button" class="btn btn-primary waves-effect" style="float: right; padding-right: 25px;" value="Print" onclick="PrintDiv();" />
                    </div>
                    </div>
                </form>
                

                <!---- Search ---->
                <table id="mytable" class="table table-bordred table-striped" style="width: 100% !important;">

        <tbody>  
        <?php
        if(count($listofSerialNos)>0)
        {           
            $sno=1;
            if(isset($_GET['offset']) && (int)$_GET['offset']>0)
            {
              $sno=(((int)$_GET['offset']-1)*LIST_PAGE_LIMIT)+1;
            }
            foreach($listofSerialNos as $key=>$value)
            {
              echo ($sno % 2 == 0) ? '' : '<tr>';
                    
            ?>
              <td>
                <table>
                    <tr>
                      <td>IMEI: <?php echo $value['s_imei']; ?></td>
                      <td rowspan="4"><?php 
                        $CI =& get_instance();
                        $CI->load->library('ciqrcode');

                        $params['data'] = $value['s_imei'] . ';' . $value['s_iccid'] . ';' . $value['s_serial_number'];
                        $params['level'] = 'H';
                        $params['size'] = 4;
                        $params['savename'] = FCPATH . 'qrcodes/' . $value['s_imei'] . '.png';
                        $CI->ciqrcode->generate($params);

                        echo '<img src="'.base_url() . 'qrcodes/' . $value['s_imei'] . '.png" />'; ?></td>
                      </tr><tr>
                      <td>ICCID: <?php echo $value['s_iccid']; ?></td>
                      </tr><tr>
                      <td>S/N: <?php echo $value['s_serial_number']; ?></td>
                      </tr><tr>
                      <td>MADE IN INDIA</td>
                      </tr><tr>
                      <td>www.psdn.live</td>
                  </tr>
                   <tr>
                        
                    </tr>
                  </table>
               </td>
            <?php echo ($sno % 2 == 0 || count($listofSerialNos) == $sno) ? '</tr>' : ''; ?>
            <?php 
            $sno++;
            } 
        }else{
        ?>
        <tr style=" text-align: center;">
          <td colspan="6">No Records Found</td>           
        </tr>
        <?php 
        }
        ?>
            </tbody>
        
          </table>
          
          <div style="float:right;" id="pageformat"></div>
                   </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Validation -->
        
        </div>
    </section>
  
  <!--- Model Dialog ---->
  
  
  <?php $this->load->view('common/admin_login_css_js'); ?>      
  <script>  
    $(function() {
      $('#pageformat').pagination({
        items: '<?php echo $totalNoOfSerialNos; ?>',
        itemsOnPage: '25',
        cssStyle: 'light-theme',
        onPageClick:function(no){
          var offsetValue=$('#offset').val();
          if(offsetValue==no)
          {
            
          }
          else
          {
            $('#offset').val(no);             
            $('#searchfiltersubmit').trigger('click');
          }
        }
      });
      <?php
      if(isset($_GET['offset']) && (int)$_GET['offset']>0)
      { ?>
        $('#pageformat').pagination('selectPage', '<?php echo $_GET['offset']; ?>');
      <?php } ?>
    });

    function PrintDiv() {    
        var divToPrint = document.getElementById('divToPrint');
        var popupWin = window.open('', '_blank', 'width=1600,height=600');
        popupWin.document.open();
        popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
        popupWin.document.close();
    }
  </script>
</body>
</html>