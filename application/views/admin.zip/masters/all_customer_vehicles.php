<?php
$this->load->view('common/admin_login_header');
$this->load->view('common/admin_login_css_js');
?>
<style>
     body
    {
      overflow-y: hidden;
    }
    .content-header
    {
      margin-top: -70px;
    }
    #searchbar
    {
       margin-left: 4%;
       margin-top: 20%;
       padding:15px;
       border-radius: 10px;
    }
   #list
   {
    font-size:  1.5em;
    margin-left: 5%;
    margin-right: 20%;
   }
   .vehicles
   {
    display: list-item;
   }
    .sidenav 
    {
        height: 100%;
        width: 300px;
        position: fixed;
        z-index: 1;
        top: 80px;
        right: 0;
        margin-bottom: 80px;
        background-color: rgb(255, 255, 255);
        overflow-x: hidden;
        padding-top: 50px;
        border: 1px solid lightgray;
    }

    .sidenav a 
    {
        padding: 6px 8px 6px 40px;
        text-decoration: none;
        font-size: 10px;
        color: #818181;
        display: block;
    }

    .sidenav a:hover 
    {
        color: #f1f1f1;
    }
    .card {
            position: relative;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-direction: column;
            flex-direction: row;
            width: 300px;
            word-wrap: break-word;
            background-color: #fff;
            background-clip: border-box;
            border-bottom: 1px solid rgba(0, 0, 0, .125);
            border-radius: .25rem;
        }

    .main 
    {
        margin-right: 300px;
        margin-bottom: -5px;
        /* Same as the width of the sidenav */
        font-size: 28px;
        /* Increased text to enable scrolling */
        padding: 0px 10px;
        /* overflow-y: auto; */
        height: 500px;
    }
    .pd-1 
    {
        padding: 12px;
        font-size: 13px;
        margin-left: -20px;
    }
    .pdt-1 
    {
        padding-top: 6px;
    }

    .pdb-1 
    {
        padding-bottom: 6px;
    }

    .pd0 
    {
        padding: 0;
    }

    .mr-1 
    {
        margin: 12px;
    }

    .mrb-1 
    {
        margin-bottom: 12px;
    }

    .bgc-blue 
    {
        background-color: rgb(77, 209, 235);
    }

    .float-right 
    {
        float: right;
        position: absolute;
        right: 12px;
        top: 12px;
    }

    .mr-0 
    {
       margin: 0;
    }
    .head
    {
       text-align:center;
    }
    .veh-list
    {
       margin-top: -60px;
    }
    .dashboard
    {
       margin-top: -20px;
    }

    @media screen and (max-height: 450px) 
    {
        .sidenav 
        {
          padding-top: 15px;
        }
        .sidenav a 
        {
           font-size: 18px;
        }
    }
    
  </style>
 <script src="<?php echo base_url(); ?>public/js/frontend.js?id=<?php echo rand(); ?>"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css"
        integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

  <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
  <script src="https://unpkg.com/@google/markerclustererplus@4.0.1/dist/markerclustererplus.min.js"></script>
  <script 
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAx3BvK2E1sHk6jTJGF8ty7Brkh-nP4gd4&callback=initMap"
      defer></script>
      <!-- https://maps.googleapis.com/maps/api/js?key=AIzaSyAn_pLYhhBqRD1Cx_RzHLSAUe9PAclmTsw&callback=initMap&libraries=&v=weekly -->
  </head>
  <body class="<?php echo THEME_BODY_HEADER_COLOR; ?>">
    <?php $this->load->view('common/top_search_bar');?>
    <div class="dashboard">
	    <?php $this->load->view('common/dashboard_top_bar');?>
    </div>
    <?php $this->load->view('common/left_side_bar');?>
    <!-- input tag -->
    <!--SIDEBAR STARTS HERE-->
    <div  id="test" class="sidenav mr-0  pd0">
      <div id="driver-details " class="bgc-blue pd-1 mrb-1">
          <h3 class="head">Vehicles List</h3>
      </div>
      <div class="veh-list">
       <div class="pd-1">
        <input id="searchbar" class="form-control" onkeyup="search_vehicle()"  type="search" name="search_imei" placeholder="Search vehicles....">
       </div>
       <?php
        for ($i = 0; $i < count($veh_lat_long); $i++) 
        {
        if ($veh_lat_long[$i]['latitude'] != '' && $veh_lat_long[$i]['longitude'] != '' && $veh_lat_long[$i]['imei'] != '' && $veh_lat_long[$i]['vehicleRegNumber'] != '') 
         {
        ?>
       <div id="list" class="vehicles" onclick="zoom_latlng(<?php echo $veh_lat_long[$i]['latitude'] ?>,<?php echo $veh_lat_long[$i]['longitude'] ?>)">
        <div class="card pd-1">
          <div>
            <p><b>IMEI NUMBER:</b>     <?php echo $veh_lat_long[$i]['imei']; ?></p>
            <p><b>VEHICLE NUMBER:</b>  <?php echo $veh_lat_long[$i]['vehicleRegNumber']; ?></p>
          </div>
        </div>
       </div>
       <?php
        }
       }
       ?>
      </div>
    </div>
    <!--SIDEBAR ENDS HERE-->
   <div class="main">
    <section class="content">
        <div id="map" style="height: 400px;"></div>
    </section>
   </div>

	<script>
  const locations = [];
//   const data = <?php //echo $new?>;
//   if(data.length !=0){
//     for (j = 0; j < data.length; j++) {
//       if (data[j]['latitude'] != '' && data[j]['longitude'] != '' && data[j]['vtrackingId'] != '' && data[j]['imei'] != '') {
//         var val = { "vehid": parseInt(data[j]['vtrackingId']), "lat": parseFloat(data[j]['latitude']) ,"lng": parseFloat(data[j]['longitude']), "imei": data[j]['imei'] };
//         locations.push(val);
//       }
//     }
//     console.log(locations);
//     /* for ($j = 0; $j < data; $j++) { 
//       if (data[$j]['latitude'] != '' && data[$j]['longitude'] != '' && data[$j]['vtrackingId'] != '' && data[$j]['imei'] != '') {
//         var val = { vehid: data[$j]['vtrackingId'], lat: data[$j]['latitude'] ,lng: data[$j]['longitude'] imei: data[$j]['imei'] };
//         locations.push(val);
//       }
//     } */
//   }
   <?php for ($i = 0; $i < count($veh_lat_long); $i++) {
     if ($veh_lat_long[$i]['latitude'] != '' && $veh_lat_long[$i]['longitude'] != '' && (int)$veh_lat_long[$i]['longitude'] != 0 && $veh_lat_long[$i]['vtrackingId'] != '' && $veh_lat_long[$i]['imei'] != '') {?>
         var val = { vehid: <?php echo $veh_lat_long[$i]['vtrackingId']; ?>, lat:<?php echo $veh_lat_long[$i]['latitude']; ?>,lng:<?php echo $veh_lat_long[$i]['longitude']; ?>,imei:<?php echo $veh_lat_long[$i]['imei']; ?>};
         locations.push(val);
   <?php
    }}?>
   var map;
   var c=0;
   function zoom_latlng(a,b)
   {
     var c=1;
     var lt=a;
     var lang=b;
     initMap1(lt,lang,c);
   }
  function initMap()
  {
    map = new google.maps.Map(document.getElementById("map"), {
      zoom: 8,
      center: { lat: 11.1271, lng: 78.6569},
    });
    var infoWin = new google.maps.InfoWindow();
    const markers = locations.map((location, i) => {
    var marker = new google.maps.Marker({
      position: location,
      url: "<?php echo base_url() . 'portal/tracking?vehId=' ?>"+location.vehid+"&Sid="+location.imei+"&lat="+location.lat+"&lng="+location.lng,
      });

     google.maps.event.addListener(marker, 'click', (function(marker) {
      return function() {
        window.location.href = marker.url;
      }
     })(marker));

      google.maps.event.addListener(marker, 'mouseover', function(evt) {
      infoWin.setContent("IMEI NUMBER:"+JSON.stringify(location.imei)+"   "+"VEHICLE ID:"+JSON.stringify(location.vehid));
      infoWin.open(map, marker);
      })

      return marker;
    });

    new MarkerClusterer(map, markers, {
    imagePath:
      "https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m",
    });

    //$("#test").css("display", "block");
    // var mapDiv = document.getElementById('map').getElementsByTagName('div')[0];
    // mapDiv.appendChild(document.getElementById("test"));
  }
  function initMap1(lt,lang,c)
  { 
   // console.log(JSON.stringify(locations));
    if(c==1)
    {
      map = new google.maps.Map(document.getElementById("map"), {
        zoom: 15,
        center: { lat: lt, lng: lang},
      });
    }
    else
    {
      map = new google.maps.Map(document.getElementById("map"), {
        zoom: 5,
        center: { lat: 11.1271, lng: 78.6569},
      });
    }

    var infoWin = new google.maps.InfoWindow();

    const markers = locations.map((location, i) => {
    var marker = new google.maps.Marker({
      position: location,
      url: "<?php echo base_url() . 'portal/tracking?vehId=' ?>"+location.vehid+"&Sid="+location.imei+"&lat="+location.lat+"&lng="+location.lng,
      });

     google.maps.event.addListener(marker, 'click', (function(marker) {
      return function() {
        window.location.href = marker.url;
      }
     })(marker));

      google.maps.event.addListener(marker, 'mouseover', function(evt) {
      infoWin.setContent("IMEI NUMBER:"+JSON.stringify(location.imei)+"   "+"VEHICLE ID:"+JSON.stringify(location.vehid));
      infoWin.open(map, marker);
      })

      return marker;
    });

    new MarkerClusterer(map, markers, {
    imagePath:
      "https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m",
    });

    // $("#test").css("display", "block");
    // var mapDiv = document.getElementById('map').getElementsByTagName('div')[0];
    // mapDiv.appendChild(document.getElementById("test"));
  }
  
	</script>
  </body>
</html>
