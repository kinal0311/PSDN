<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <style type="text/css">
      </style>
      <style type="text/css">
      </style>
   </head>
   <body>
      <table border="0" cellpadding="1" cellspacing="1" style="padding:15px 0 15px 0;border-bottom:1px solid #000;">
         <tbody>
            <tr>
               <td colspan="2" style="height:5px;">
               </td>
            </tr>
            <tr>
               <td colspan="2" style="text-align:center;">
                  <img style="width:200px;" src="download.jpg">
               </td>
            </tr>
            <tr>
               <td colspan="2" style="height:5px;">
               </td>
            </tr>
         </tbody>
      </table>
      <table border="0" cellpadding="1" cellspacing="1" style="border-bottom:1px solid #000;padding-bottom:10px;">
         <tbody>
            <tr>
               <td style="text-align:center;font:20px arial;color:#333;">
                  <h1 style="text-align:center;font:20px arial;color:#333;">Invoice Number : 42</h1>
               </td>
               <td class="head_border" style="font:20px arial;color:#333;">
                  <h1 style="text-align:center;font:20px arial;color:#333;">June 23, 2017</h1>
               </td>
            </tr>
         </tbody>
      </table>
      <table border="0" cellpadding="0" cellspacing="0">
         <tbody>
            <tr>
               <td colspan="4" style="height:5px;">
               </td>
            </tr>
            <tr>
               <td style="border-bottom:1px solid #000;">
                  <strong style="padding-bottom:5px;">Passenger Name</strong>
               </td>
               <td style="border-bottom:1px solid #000;">
                  <strong style="padding-bottom:5px;">Pick up Location</strong>
               </td>
               <td style="border-bottom:1px solid #000;">
                  <strong style="padding-bottom:5px;">Dropoff Location</strong>
               </td>
               <td style="border-bottom:1px solid #000;">
                  <strong style="padding-bottom:5px;">Journey Date</strong>
               </td>
            </tr>
            <tr>
               <td colspan="4" style="height:5px;">
               </td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;">Senthil</td>
               <td style="font:15px arial;color:#666;">5 Windflower Ct, Fredericton, NB E3B 0E4, Canada</td>
               <td style="font:15px arial;color:#666;">5 Windflower Court ,Fredericton, NB E3B 0E4, Canada ,Canada</td>
               <td style="font:15px arial;color:#666;">2017-06-23 12:07:17</td>
            </tr>
            <tr>
               <td colspan="4" style="height:40px;"></td>
            </tr>
            <tr>
               <td colspan="4">
                  <table width="100%" cellpadding="1" cellspacing="1" style="border-bottom:1px solid #000;width:100%;padding-bottom:15px;">
                     <tbody>
                        <tr>
                           <td>
                              <h2 style="font:20px arial;color:#333;margin:0;">Fare Detail</h2>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </td>
            </tr>
         </tbody>
      </table>
      <table border="0" cellpadding="5" cellspacing="0">
         <tbody>
            <tr>
               <td colspan="4" style="height:5px;"></td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;"><strong style="padding-top:5px;font:15px arial;color:#666;">Base Fare</strong></td>
               <td style="font:15px arial;color:#000;">$8.5</td>
               <td></td>
               <td></td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;"><strong style="padding-top:5px;font:15px arial;color:#666;">Waiting Fare</strong></td>
               <td style="font:15px arial;color:#000;">$0</td>
               <td></td>
               <td></td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;"><strong style="padding-top:5px;font:15px arial;color:#666;">Minutes Fare</strong></td>
               <td style="font:15px arial;color:#000;">$2</td>
               <td></td>
               <td></td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;"><strong style="padding-top:5px;font:15px arial;color:#666;">Night Fare</strong></td>
               <td style="font:15px arial;color:#000;">$0</td>
               <td></td>
               <td></td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;"><strong style="padding-top:5px;font:15px arial;color:#666;">Sub Total</strong></td>
               <td style="font:15px arial;color:#000;">$10.5</td>
               <td></td>
               <td></td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;"><strong style="padding-top:5px;font:15px arial;color:#666;">Tax</strong></td>
               <td style="font:15px arial;color:#000;">$1.31</td>
               <td></td>
               <td></td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;"><strong style="padding-top:5px;font:15px arial;color:#666;">Payment Type</strong></td>
               <td style="font:15px arial;color:#000;">New card</td>
               <td></td>
               <td></td>
            </tr>
            <tr>
               <td style="font:15px arial;color:#666;"><strong style="padding-top:5px;font:15px arial;color:#666;">Total Amount</strong></td>
               <td style="font:15px arial;color:#000;">$11.81</td>
               <td></td>
            </tr>
         </tbody>
      </table>
   </body>
</html>