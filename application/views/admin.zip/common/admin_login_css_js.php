﻿	<!-- Select Plugin Js -->
    <script src="<?php echo base_url() ?>public/plugins/bootstrap-select/js/bootstrap-select.js"></script>
    <!-- Bootstrap Core Js -->
    <script src="<?php echo base_url() ?>public/plugins/bootstrap/js/bootstrap.js"></script>
    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo base_url() ?>public/plugins/node-waves/waves.js"></script>
	   
	<!-- Slimscroll Plugin Js -->
    <script src="<?php echo base_url() ?>public/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
	<!-- Autosize Plugin Js -->
    <script src="<?php echo base_url() ?>public/plugins/autosize/autosize.js"></script>

	 <!-- Demo Js -->
    <script src="<?php echo base_url() ?>public/js/demo.js"></script>
	<!-- SweetAlert Plugin Js -->
    <script src="<?php echo base_url() ?>public/plugins/sweetalert/sweetalert.min.js"></script>
		    <!-- Custom Js -->
    <script src="<?php echo base_url() ?>public/js/admin.js"></script>